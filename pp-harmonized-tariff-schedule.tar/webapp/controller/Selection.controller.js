sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/type/String",
	"sap/m/ColumnListItem",
	"sap/m/Label",
	"sap/m/SearchField",
	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/table/Column",
	"sap/m/Column",
	"sap/m/Text",
	"sap/m/MessageToast",
	"sap/ui/core/BusyIndicator",
	"sap/m/MessageBox",
	"sap/ui/comp/smartvariants/PersonalizableInfo"
],
	function (Controller, TypeString, ColumnListItem, Label, SearchField, Token,
		Filter, FilterOperator, UIColumn, MColumn, Text,
		MessageToast, BusyIndicator, MessageBox, PersonalizableInfo) {
		"use strict";

		return Controller.extend("com.wl.pp.zharmonizedtariff.controller.Selection", {
			onInit: function () {
				 
				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this._oMultiInputMaterial = this.byId("multiInput");
				this._oMultiInputPlant = this.byId("multiInput1");
				this._oMultiInputAltBOM = this.byId("multiInput2");

				// add validator
				var fnValidator = function (fieldSource) {

					return (args) => {
						var text = args.text; 
						var otoken = new Token({ key: text, text: '=' + text });
						otoken.addCustomData(new sap.ui.core.CustomData(
							{
								"key": "range",
								"value": {
									"exclude": false,
									"operation": "EQ",
									"keyField": fieldSource,
									"value1": text,
									"value2": null
								},
								"writeToDom": false
							}));

						return otoken
					}


				};

				this._oMultiInputMaterial.addValidator(fnValidator("Material"));
				this._oMultiInputPlant.addValidator(fnValidator("Plant"));
				this._oMultiInputAltBOM.addValidator(fnValidator("Alternative_BOM"));

				// // variant management
				this.applyData = this.applyData.bind(this);
				this.fetchData = this.fetchData.bind(this);
				this.getFiltersWithValues = this.getFiltersWithValues.bind(this);

				this.oSmartVariantManagement = this.getView().byId("pageVariantId");
				this.oFilterBar = this.getView().byId("filterbar");

				this.oFilterBar.registerFetchData(this.fetchData);
				this.oFilterBar.registerApplyData(this.applyData);
				this.oFilterBar.registerGetFiltersWithValues(this.getFiltersWithValues);

				var oPersInfo = new PersonalizableInfo({
					type: "filterBar",
					keyName: "persistencyKey",
					dataSource: "",
					control: this.oFilterBar
				});
				this.oSmartVariantManagement.addPersonalizableControl(oPersInfo);
				this.oSmartVariantManagement.initialise(function () { }, this.oFilterBar);

				// settings for Smart table
				this._setSmartTableSettings();


			},

			//get filter and the display data 
			Onpressexecute: function () {
				var sPlantValue = this._oMultiInputPlant.getValue(),
					aPlantToken = this._oMultiInputPlant.getTokens(),
					sMaterial = this._oMultiInputMaterial.getValue(),
					aMatToken = this._oMultiInputMaterial.getTokens(),
					sAltBom = this._oMultiInputAltBOM.getValue(),
					aAltBomToken = this._oMultiInputAltBOM.getTokens(),
					aFilter = [];

				// If plant value does not exists or plant token does not exists return
				if (!sPlantValue && aPlantToken.length === 0) {
					MessageToast.show("Plant cannot be empty");
					return;

				}
				// get selected plant bvalue filters and push it to filter array
				if (aPlantToken.length > 0) {
					aPlantToken.forEach(token => {
						var oFilter = this._formFilter(token, "Plant");
						if (oFilter)
							aFilter.push(oFilter);
					});
				}
				//if plant value exists then add it to array
				else if (sPlantValue) {
					aFilter.push(new Filter({
						path: "Plant",
						operator: FilterOperator.EQ,
						value1: sPlantValue.toUpperCase()
					}));
				}
				//if material token exists add to filter
				if (aMatToken.length > 0) {
					aMatToken.forEach(token => {
						var oFilter = this._formFilter(token, "Material");
						if (oFilter)
							aFilter.push(oFilter);
					});
				}
				//if material value exists then add it to array
				else if (sMaterial) {
					aFilter.push(
						new Filter({
							path: "Material",
							operator: FilterOperator.EQ,
							value1: sMaterial.toUpperCase()
						}));
				}

				//if altbom token exists add to filter
				if (aAltBomToken.length > 0) {
					aAltBomToken.forEach(token => {
						var oFilter = this._formFilter(token, "Alternative_BOM");
						if (oFilter)
							aFilter.push(oFilter);
					});
				}
				//if altbom value exists then add it to array
				else if (sAltBom) {
					aFilter.push(
						new Filter({
							path: "Alternative_BOM",
							operator: FilterOperator.EQ,
							value1: sAltBom.toUpperCase()
						}));
				}

				if (aFilter) {
					BusyIndicator.show();
					this._forFilterData(aFilter);
				}

			},

			//function to navigate to second screen if data exists
			_forFilterData: function (aFilter) {
				var oDataModel = this.getView().getModel();
				this.getView().getModel("local").setProperty("/filterData", aFilter);
				oDataModel.read("/ZPP_CDS_HTS_CLF/$count", {
					filters: aFilter,
					success: function (oResponse) {
						if (oResponse > 0) {

							this.fnReset();
						}
						else {
							MessageToast.show("No Data found");
						}
						BusyIndicator.hide();
					}.bind(this),
					error: function (oError) {
						MessageBox.error(oError.responseText);
						BusyIndicator.hide();

					}.bind(this)
				});

			},
			//function to return formed filter object with inputted value and field path
			_formFilter: function (oToken, sFieldPath) {
				var oFilterObj = {};
				if (oToken
					.getAggregation("customData") && oToken
						.getAggregation("customData")[0] && oToken
							.getAggregation("customData")[0]
							.getProperty("key")) {
					var sKeyType = oToken
						.getAggregation("customData")[0]
						.getProperty("key");
					switch (sKeyType) {
						case "row": {
							oFilterObj = new Filter({
								path: sFieldPath,
								operator: FilterOperator.EQ,
								value1: oToken.getKey(),
							});
							break;
						}
						case "range": {
							var oValue = oToken
								.getAggregation("customData")[0]
								.getProperty("value");
							oFilterObj = new Filter({
								path: sFieldPath, //oValue.keyField,
								operator: FilterOperator[oValue.operation],
								value1: oValue.value1,
								value2: oValue.value2
							});
						}
					}
				}
				// token added through validator
				else {
					oFilterObj = new Filter({
						path: sFieldPath,
						operator: FilterOperator.EQ,
						value1: oToken.getKey()
					});
				}
				return oFilterObj;
			},


			// display valuehelp when Material valuehelp is requested
			onMaterialRequested: function () {
				this._oBasicSearchField = new SearchField();
				this.loadFragment({
					name: "com.wl.pp.zharmonizedtariff.view.Fragments.ValueHelpDialogFilterbar"
				}).then(function (oDialog) {
					var oFilterBar = oDialog.getFilterBar(), oColumnProductCode, oColumnProductName, oColumnPlantProductName;
					this._oVHD = oDialog;

					this.getView().addDependent(oDialog);

					// Set key fields for filtering in the Define Conditions Tab
					oDialog.setRangeKeyFields([{
						label: "Material",
						key: "Material",
						type: "string",
						typeInstance: new TypeString({}, {
							maxLength: 8
						})
					}]);

					// Set Basic Search for FilterBar
					oFilterBar.setFilterBarExpanded(false);
					oFilterBar.setBasicSearch(this._oBasicSearchField);

					// Trigger filter bar search when the basic search is fired
					this._oBasicSearchField.attachSearch(function () {
						oFilterBar.search();
					});

					oDialog.getTableAsync().then(function (oTable) {



						// For Desktop and tabled the default table is sap.ui.table.Table
						if (oTable.bindRows) {
							// Bind rows to the ODataModel and add columns
							oTable.bindAggregation("rows", {
								path: "/I_MaterialPlant",
								events: {
									dataReceived: function () {
										oDialog.update();
									}
								}
							});
							oColumnProductCode = new UIColumn({ label: new Label({ text: "Material" }), template: new Text({ wrapping: false, text: "{Material}" }) });
							oColumnProductCode.data({
								fieldName: "Material"
							});
							oColumnProductName = new UIColumn({ label: new Label({ text: "Material Description" }), template: new Text({ wrapping: false, text: "{Material_Text}" }) });
							oColumnProductName.data({
								fieldName: "Material_Text"
							});
							oColumnPlantProductName = new UIColumn({ label: new Label({ text: "Plant" }), template: new Text({ wrapping: false, text: "{Plant}" }) });
							oColumnPlantProductName.data({
								fieldName: "Plant"
							});

							oTable.addColumn(oColumnProductCode);
							oTable.addColumn(oColumnProductName);
							oTable.addColumn(oColumnPlantProductName);

						}

						// For Mobile the default table is sap.m.Table
						if (oTable.bindItems) {
							// Bind items to the ODataModel and add columns
							oTable.bindAggregation("items", {
								path: "/I_MaterialPlant",
								template: new ColumnListItem({
									cells: [new Label({ text: "{Material}" }), new Label({ text: "Material Description" }), new Label({ text: "{Plant}" })]
								}),
								events: {
									dataReceived: function () {
										oDialog.update();
									}
								}
							});

							oTable.addColumn(new MColumn({ header: new Label({ text: "Material" }) }));
							oTable.addColumn(new MColumn({ header: new Label({ text: "Material_Text" }) }));
							oTable.addColumn(new MColumn({ header: new Label({ text: "Plant" }) }));
						}
						oDialog.update();
					}.bind(this));

					oDialog.setTokens(this._oMultiInputMaterial.getTokens());
					oDialog.open();
				}.bind(this));


			},
			_checkPlantAvailability: function (oModel, aFilters) {
				return new Promise(function (resolve, reject) {
					oModel.read("/I_MaterialPlant", {
						filters: aFilters,
						success: function (oData) {
							resolve(oData);
						},
						error: function (oError) {
							reject([]);
						},
					});
				});
			},
			onMatValueHelpOkPress: function (oEvent) {
				// --filter
				var aFilter = [];
				var aMaterial = [], aMaterialPlantFilter = [], aMaterialPlantComb = [];
				var aTokens = oEvent.getParameter("tokens");
				this._oMultiInputMaterial.setTokens(aTokens);
				aTokens.forEach(async function (oToken) {
					var sMaterialKey = oToken.getKey();
					// if selected Material is of defined condition type
					if (sMaterialKey === "range_0") {
						//set Material filter condition and Material selection info
						var oFilterValue = oToken.getAggregation("customData")[0].getProperty("value");
						aMaterial.push(sMaterialKey);
						var aPlantMaterial = await this._checkPlantAvailability(this.getView().getModel(), [new Filter("Material", FilterOperator[oFilterValue.operation], oFilterValue.value1, oFilterValue.value2)]);

						// create plant combo filter
						if (aPlantMaterial.results.length > 0) {
							//set plant Material filter combo
							this.getView().getModel("local").setProperty("/selectedMaterialPlantComb", aPlantMaterial.results);
							var aplant = aPlantMaterial.results.map(row => row.Plant);
							aMaterialPlantFilter = aplant.map(row => new Filter({
								path: "Plant",
								operator: FilterOperator.EQ,
								value1: row,
							}));
							this.getView().getModel("local").setProperty("/selectedMaterialPlantFilter", aMaterialPlantFilter);
						}
						// if no plant returned, clear the plant filter condition  along with plant 
						else {

							this.getView().getModel("local").setProperty("/selectedMaterialPlantFilter", []);
							this.getView().getModel("local").setProperty("/selectedMaterialPlantComb", []);
							MessageToast.show("No Plant found for the Material")
						}
					}
					// if token is not regular selection
					else {
						aMaterial.push(sMaterialKey);
						var sPlant = oToken.getAggregation("customData")[0].getProperty("value").Plant;
						aMaterialPlantComb.push(
							{
								"Material": sMaterialKey,
								"Plant": sPlant
							}
						);
						aMaterialPlantFilter.push(new Filter({
							path: "Plant",
							operator: FilterOperator.EQ,
							value1: sPlant,
						}));
					}

				}, this);
				//create filter for Material 
				aTokens.forEach((token) => {
					var oFilter = this._formFilter(token, "Material");
					if (oFilter) aFilter.push(oFilter);
				});

				if (aMaterial.length > 0) {
					var oModel = this.getView().getModel("local");

					// Set the collected material, condition, plant filter to the model
					oModel.setProperty("/selectedMatCondition", aFilter);
					oModel.setProperty("/selectedMaterial", aMaterial);
					oModel.setProperty("/selectedMaterialPlantFilter", aMaterialPlantFilter);
					oModel.setProperty("/selectedMaterialPlantComb", aMaterialPlantComb);
					//set the variantmanagement status to edited
					this.onSelectionChange(oEvent);

				}

				this._oVHD.destroy();
				//clear plant and altbom selections
				this._oMultiInputPlant.setValue("");
				this._oMultiInputPlant.removeAllTokens();
				this._oMultiInputAltBOM.setValue("");
				this._oMultiInputAltBOM.removeAllTokens();
				//set the variantmanagement status to edited
				this.onSelectionChange(oEvent);

			},
			onMaterialTokenUpdate: async function (oEvent) {
				var aTokens = oEvent.getSource().getTokens();
				var sType = oEvent.getParameter("type"),
					aAddedTokens = oEvent.getParameter("addedTokens"),
					aRemovedTokens = oEvent.getParameter("removedTokens"),
					aContexts = this.getView().getModel("local").getProperty("/selectedMatCondition");
				var aMaterialPlantComb = this.getView().getModel("local").getProperty("/selectedMaterialPlantComb");
				var aMaterialPlantFilter = this.getView().getModel("local").getProperty("/selectedMaterialPlantFilter");
				switch (sType) {
					// add new context to the data of the model, when new token is being added
					case "added":
						aAddedTokens.forEach(function (oToken) {
							aContexts.push(new Filter("Material", FilterOperator.EQ, oToken.getKey()));
							//aContexts.push({ key: oToken.getKey(), text: oToken.getText() });
						});
						break;
					// remove contexts from the data of the model, when tokens are being removed
					case "removed":
						aRemovedTokens.forEach(function (oToken) {
							aContexts = aContexts.filter(function (oContext) {
								//find the object from the material plant combo and delete it
								aMaterialPlantComb = aMaterialPlantComb.filter(object => {
									return object.Material !== oToken.getKey();
								});
								return oContext.oValue1 !== oToken.getKey();
							});
						});
						break;
					default:
						break;
				}
				this.getView().getModel("local").setProperty("/selectedMatCondition", aContexts);
				//if all material tokens are removed 
				if (aContexts.length <= 0) {
					this.getView().getModel("local").setProperty("/selectedMaterialPlantComb", []);
					this.getView().getModel("local").setProperty("/selectedMaterialPlantFilter", []);
				} else {
					var aPlantMaterial = await this._checkPlantAvailability(this.getView().getModel(), aContexts);
					if (aPlantMaterial.results.length > 0) {
						//set plant material filter combo
						this.getView().getModel("local").setProperty("/selectedMaterialPlantComb", aPlantMaterial.results);
						var aplant = aPlantMaterial.results.map(row => row.Plant);
						var aMaterialPlantFilter = aplant.map(row => new Filter({
							path: "Plant",
							operator: FilterOperator.EQ,
							value1: row,
						}));
						this.getView().getModel("local").setProperty("/selectedMaterialPlantFilter", aMaterialPlantFilter);
					}
					else {
						MessageToast.show("No Plant found for the Material");
						this.getView().getModel("local").setProperty("/selectedMaterialPlantComb", []);
						this.getView().getModel("local").setProperty("/selectedMaterialPlantFilter", []);
					}
				}
				//clear plant and altbom selections
				this._oMultiInputPlant.setValue("");
				this._oMultiInputPlant.removeAllTokens();
				this._oMultiInputAltBOM.setValue("");
				this._oMultiInputAltBOM.removeAllTokens();
				//set the variantmanagement status to edited
				this.onSelectionChange(oEvent);
			},

			onMatValueHelpCancelPress: function () {
				this._oVHD.destroy();

			},

			onMatFilterBarSearch: function (oEvent) {
				var sSearchQuery = this._oBasicSearchField.getValue(),
					aSelectionSet = oEvent.getParameter("selectionSet");

				var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
					if (oControl.getValue()) {
						aResult.push(new Filter({
							path: oControl.getName(),
							operator: FilterOperator.Contains,
							value1: oControl.getValue()
						}));
					}

					return aResult;
				}, []);

				aFilters.push(new Filter({
					filters: [
						new Filter({ path: "Material", operator: FilterOperator.Contains, value1: sSearchQuery }),
						new Filter({ path: "Material_Text", operator: FilterOperator.Contains, value1: sSearchQuery }),
						new Filter({ path: "Plant", operator: FilterOperator.Contains, value1: sSearchQuery })
					],
					and: false
				}));

				this._filterTable(new Filter({
					filters: aFilters,
					and: true
				}));
			},
			// function to execute when material value
			onMaterialValChange: async function (oEvent) {
				//fetch the material value 
				var sMaterial = this._oMultiInputMaterial.getValue();
				// fetch the plant   based on enetered material value
				var aPlantMaterial = await this._checkPlantAvailability(this.getView().getModel(), [new Filter("Material", FilterOperator.EQ, sMaterial)]);

				// create plant combo filter
				if (aPlantMaterial.results.length > 0) {
					//set plant material filter combo
					this.getView().getModel("local").setProperty("/selectedMaterialPlantComb", aPlantMaterial.results);
					var aplant = aPlantMaterial.results.map(row => row.Plant);
					var aMaterialPlantFilter = aplant.map(row => new Filter({
						path: "Plant",
						operator: FilterOperator.EQ,
						value1: row,
					}));
					this.getView().getModel("local").setProperty("/selectedMaterialPlantFilter", aMaterialPlantFilter);
				}

				else {
					MessageToast.show("No Plant found for the Material");
					this.getView().getModel("local").setProperty("/selectedMaterialPlantComb", []);
					this.getView().getModel("local").setProperty("/selectedMaterialPlantFilter", []);
				}
				//clear plant and altbom selections
				this._oMultiInputPlant.setValue("");
				this._oMultiInputPlant.removeAllTokens();
				this._oMultiInputAltBOM.setValue("");
				this._oMultiInputAltBOM.removeAllTokens();
				//set the variantmanagement status to edited
				this.onSelectionChange(oEvent);
			},

			
			_filterTable: function (oFilter) {
				var oVHD = this._oVHD;

				oVHD.getTableAsync().then(function (oTable) {
					if (oTable.bindRows) {
						oTable.getBinding("rows").filter(oFilter);
					}
					if (oTable.bindItems) {
						oTable.getBinding("items").filter(oFilter);
					}

					// This method must be called after binding update of the table.
					oVHD.update();
				});
			},

			onPlantRequested: async function () {

				var aMaterialPlantFilter = await this._getMaterialPlantFilter();
				this._oBasicSearchField = new SearchField();

				this.loadFragment({
					name: "com.wl.pp.zharmonizedtariff.view.Fragments.ValueHelpDialogplantFilterbar"
				}).then(function (oDialog) {
					var oFilterBar = oDialog.getFilterBar(), oColumnProductCode, oColumnProductName;
					this._oVHD = oDialog;
					this.getView().addDependent(oDialog);

					// Set key fields for filtering in the Define Conditions Tab
					oDialog.setRangeKeyFields([{
						label: "Plant",
						key: "Plant",
						type: "string",
						typeInstance: new TypeString({}, {
							maxLength: 4
						})
					}]);

					// Set Basic Search for FilterBar
					oFilterBar.setFilterBarExpanded(false);
					oFilterBar.setBasicSearch(this._oBasicSearchField);

					// Trigger filter bar search when the basic search is fired
					this._oBasicSearchField.attachSearch(function () {
						oFilterBar.search();
					});

					oDialog.getTableAsync().then(function (oTable) {

						// For Desktop and tabled the default table is sap.ui.table.Table
						if (oTable.bindRows) {
							// Bind rows to the ODataModel and add columns
							oTable.bindAggregation("rows", {
								path: "/I_Plant",
								filters: aMaterialPlantFilter,
								events: {
									dataReceived: function () {
										oDialog.update();
									}
								}
							});
							oColumnProductCode = new UIColumn({ label: new Label({ text: "Plant" }), template: new Text({ wrapping: false, text: "{Plant}" }) });
							oColumnProductCode.data({
								fieldName: "Plant"
							});
							oColumnProductName = new UIColumn({ label: new Label({ text: "Plant Name" }), template: new Text({ wrapping: false, text: "{PlantName}" }) });
							oColumnProductName.data({
								fieldName: "PlantName"
							});
							oTable.addColumn(oColumnProductCode);
							oTable.addColumn(oColumnProductName);
						}
						// For Mobile the default table is sap.m.Table
						if (oTable.bindItems) {
							// Bind items to the ODataModel and add columns
							oTable.bindAggregation("items", {
								path: "/I_Plant",
								filter: aMaterialPlantFilter,
								template: new ColumnListItem({
									cells: [new Label({ text: "{Plant}" }), new Label({ text: "Plant" })]
								}),
								events: {
									dataReceived: function () {
										oDialog.update();
									}
								}
							});
							oTable.addColumn(new MColumn({ header: new Label({ text: "Plant" }) }));
							oTable.addColumn(new MColumn({ header: new Label({ text: "PlantName" }) }));
						}
						oDialog.update();
					}.bind(this));

					oDialog.setTokens(this._oMultiInputPlant.getTokens());

					oDialog.open();
				}.bind(this));


			},
			onPlantTokenUpdate: function (oEvent) {
				//clear altbom selections
				this._oMultiInputAltBOM.setValue("");
				this._oMultiInputAltBOM.removeAllTokens();
				//set the variantmanagement status to edited
				this.onSelectionChange(oEvent);

			},
			//on Plant OK Press
			onPlantValueHelpOkPress: function (oEvent) {
				var aTokens = oEvent.getParameter("tokens");
				this._oMultiInputPlant.setTokens(aTokens);
				var aFilter1 = [];
				aTokens.forEach((token) => {
					var oFilter = this._formFilter(token, "Plant");
					if (oFilter) aFilter1.push(oFilter);
				});
				this.getOwnerComponent().getModel("local").setProperty("/PlantFilter", aFilter1);
				this._oVHD.destroy();
				//clear altbom selections
				this._oMultiInputAltBOM.setValue("");
				this._oMultiInputAltBOM.removeAllTokens();
				//set the variantmanagement status to edited
				this.onSelectionChange(oEvent);
			},

			onPlantValueHelpCancelPress: function () {
				this._oVHD.destroy();
			},

			onPlantFilterBarSearch: function (oEvent) {
				var sSearchQuery = this._oBasicSearchField.getValue(),
					aSelectionSet = oEvent.getParameter("selectionSet");

				var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
					if (oControl.getValue()) {
						aResult.push(new Filter({
							path: oControl.getName(),
							operator: FilterOperator.Contains,
							value1: oControl.getValue()
						}));
					}

					return aResult;
				}, []);

				aFilters.push(new Filter({
					filters: [
						new Filter({ path: "Plant", operator: FilterOperator.Contains, value1: sSearchQuery }),
						new Filter({ path: "Plant", operator: FilterOperator.Contains, value1: sSearchQuery })
					],
					and: false
				}));

				this._filterTable(new Filter({
					filters: aFilters,
					and: true
				}));
			}, 
			
			// display Alternative BOM value help 
			onALTBOMRequested: function () {
				//fetch the value of Plant and display the ALT BOM value help. 
				//if Plant is not inpuuted by user then display error
				var sPlantValue = this._oMultiInputPlant.getValue(),
					aPlantToken = this._oMultiInputPlant.getTokens(),
					aPlantFilter = [];
				var sMaterialValue = this._oMultiInputMaterial.getValue(),
					aMaterialToken = this._oMultiInputMaterial.getTokens();

				if (aMaterialToken.length > 0) {
					aMaterialToken.forEach(token => {
						var oFilter = this._formFilter(token, "Material");
						if (oFilter)
							aPlantFilter.push(oFilter);
					});
				}
				//if plant value exists then add it to array
				else if (sMaterialValue) {
					aPlantFilter.push(new Filter({
						path: "Material",
						operator: FilterOperator.EQ,
						value1: sMaterialValue.toUpperCase()
					}));
				}

				if (aPlantToken.length > 0) {
					aPlantToken.forEach(token => {
						var oFilter = this._formFilter(token, "Plant");
						if (oFilter)
							aPlantFilter.push(oFilter);
					});
				}
				//if plant value exists then add it to array
				else if (sPlantValue) {
					aPlantFilter.push(new Filter({
						path: "Plant",
						operator: FilterOperator.EQ,
						value1: sPlantValue.toUpperCase()
					}));
				}
				//if no plant is inputted display error and return
				if (!aPlantFilter || aPlantFilter.length <= 0) {
					MessageToast.show("Please enter Plant Value");
					return;
				}
				//create search field and add to the value help
				this._oAltBomSearchField = new SearchField();
				this.loadFragment({
					name: "com.wl.pp.zharmonizedtariff.view.Fragments.ValueHelpDialogAlternative_BOMFilterbar"
				}).then(function (oDialog) {
					var oFilterBar = oDialog.getFilterBar(), oColumnAltBOM, oColumnPlant;
					this._oVHD = oDialog;

					this.getView().addDependent(oDialog);

					// Set key fields for filtering in the Define Conditions Tab
					oDialog.setRangeKeyFields([{
						label: "Alternative BOM",
						key: "BillOfMaterialVariant",
						type: "string",
						typeInstance: new TypeString({}, {
							maxLength: 2
						})
					}]);
					// Set Basic Search for FilterBar
					oFilterBar.setFilterBarExpanded(false);
					oFilterBar.setBasicSearch(this._oAltBomSearchField);

					// Trigger filter bar search when the basic search is fired
					this._oAltBomSearchField.attachSearch(function () {
						oFilterBar.search();
					});
					oDialog.getTableAsync().then(function (oTable) {
						// For Desktop and tabled the default table is sap.ui.table.Table
						if (oTable.bindRows) {
							// Bind rows to the ODataModel and add columns
							oTable.bindAggregation("rows", {
								path: "/ZPP_CDS_I_HTS_MAST",
								filters: aPlantFilter,
								events: {
									dataReceived: function () {
										oDialog.update();
									}
								}
							});
							//add Alt BOM and Plant column in the table of valuehelp dialog
							oColumnAltBOM = new UIColumn({ label: new Label({ text: "Alternative BOM" }), template: new Text({ wrapping: false, text: "{BillOfMaterialVariant}" }) });
							oColumnAltBOM.data({
								fieldName: "BillOfMaterialVariant"
							});
							oColumnPlant = new UIColumn({ label: new Label({ text: "Plant" }), template: new Text({ wrapping: false, text: "{Plant}" }) });
							oColumnPlant.data({
								fieldName: "Plant"
							});
							oTable.addColumn(oColumnAltBOM);
							oTable.addColumn(oColumnPlant);
						}
						// For Mobile the default table is sap.m.Table
						if (oTable.bindItems) {
							// Bind items to the ODataModel and add columns
							oTable.bindAggregation("items", {
								path: "/ZPP_CDS_I_HTS_MAST",
								filters: aPlantFilter,
								template: new ColumnListItem({
									cells: [new Label({ text: "{BillOfMaterialVariant}" }), new Label({ text: "{Plant}" })]
								}),
								events: {
									dataReceived: function () {

										oDialog.update();
									}
								}
							});
							oTable.addColumn(new MColumn({ header: new Label({ text: "Alternative BOM" }) }));
							oTable.addColumn(new MColumn({ header: new Label({ text: "Plant" }) }));
						}
						oDialog.update();
					}.bind(this));
					//fetch the tokens from the alt bom field for previous selections 
					oDialog.setTokens(this._oMultiInputAltBOM.getTokens());
					oDialog.open();
				}.bind(this));
			},
			onAltBomValueHelpOkPress: function (oEvent) {
				var aTokens = oEvent.getParameter("tokens");
				this._oMultiInputAltBOM.setTokens(aTokens);
				var aFilter2 = [];
				aTokens.forEach((token) => {
					var oFilter = this._formFilter(token, "Alternative_BOM");
					if (oFilter) aFilter2.push(oFilter);
				});
				this._oVHD.destroy();
			},

			onAltBomValueHelpCancelPress: function () {
				this._oVHD.destroy();

			},

			onAltBomFilterBarSearch: function (oEvent) {
				var sSearchQuery = this._oAltBomSearchField.getValue(),
					aSelectionSet = oEvent.getParameter("selectionSet");

				var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
					if (oControl.getValue()) {
						aResult.push(new Filter({
							path: oControl.getName(),
							operator: FilterOperator.Contains,
							value1: oControl.getValue()
						}));
					}

					return aResult;
				}, []);

				aFilters.push(new Filter({
					filters: [
						new Filter({ path: "BillOfMaterialVariant", operator: FilterOperator.Contains, value1: sSearchQuery }),
						new Filter({ path: "BillOfMaterialVariant", operator: FilterOperator.Contains, value1: sSearchQuery })
					],
					and: false
				}));

				this._filterTable(new Filter({
					filters: aFilters,
					and: true
				}));
			}, 
			
			//function to apply variant based on the fetched variant info
			applyData: function (aData) {
				if (!aData) {
					console.log("no variant data fetched");
					return;
				}
				aData.forEach(function (oDataObject) {
					var oControl = this.oFilterBar.determineControlByName(oDataObject.fieldName, oDataObject.groupName);

					if (oControl instanceof sap.m.MultiInput) {
						oControl.removeAllTokens();
						if (oDataObject.fieldData) {
							var oObjectData = JSON.parse(oDataObject.fieldData);
							oObjectData.forEach(function (oFieldData) {

								var oToken = new sap.m.Token({ text: oFieldData.text, key: oFieldData.key });
								oToken.addCustomData(new sap.ui.core.CustomData(oFieldData.cond));
								oControl.addToken(oToken);
							});
						}
					} else {
						oControl.setValue(oDataObject.fieldData);
					}
				}, this);
			},

			//function for variant management
			fetchData: function () {

				var aData = this.oFilterBar.getAllFilterItems().map(function (oFilterItem) {
					var oControl = oFilterItem.getControl();
					var oValue = "";
					//read the token value for multiinput value type 
					if (oControl instanceof sap.m.MultiInput) {
						oValue = oControl.getTokens().map(function (oToken) {
							return { text: oToken.getText(), cond: oToken.getAggregation("customData")[0].mProperties, key: oToken.getKey() };

						});
					} else {
						oValue = oControl.getValue();
					}
					//return the group, field name and the selected value
					return {
						groupName: oFilterItem.getGroupName(),
						fieldName: oFilterItem.getName(),
						fieldData: JSON.stringify(oValue),
					};
				});


				return aData;
			},
			getFiltersWithValues: function () {
				var aFiltersWithValue = this.oFilterBar.getFilterGroupItems().filter(function (oFilterGroupItem) {
					var oControl = oFilterGroupItem.getControl();
					return oControl && oControl.getValue && oControl.getValue().length > 0;
				});

				return aFiltersWithValue;
			},
			// function to set the variantmanagement status to edited when the token values of filter is updated
			onSelectionChange: function (oEvent) {
				this.oSmartVariantManagement.currentVariantSetModified(true);
				this.oFilterBar.fireFilterChange(oEvent);
			},
			//function for the event token change of ALT bom field
			onAltBomTokenUpdate: function (oEvent) {
				//set the variantmanagement status to edited
				this.onSelectionChange(oEvent);
			},
			//function to get the material plant combo
			_getMaterialPlantFilter: async function () {
				var aMaterialPlantFilter = [];
				//check if Material token exists incase of variants
				var aTokens = this._oMultiInputMaterial.getTokens();
				
				if (aTokens && aTokens.length > 0) {
					var aMaterialFilter = aTokens.map(row => new Filter("Material", FilterOperator.EQ, row.getKey()));
					var aPlantMaterial = await this._checkPlantAvailability(this.getView().getModel(), aMaterialFilter);

					// create plant combo filter
					if (aPlantMaterial.results.length > 0) {
						//set plant material filter combo
						this.getView().getModel("local").setProperty("/selectedMaterialPlantComb", aPlantMaterial.results);
						var aplant = aPlantMaterial.results.map(row => row.Plant);
						aMaterialPlantFilter = aplant.map(row => new Filter({
							path: "Plant",
							operator: FilterOperator.EQ,
							value1: row,
						}));
					}
				}

				return aMaterialPlantFilter;
			},
			 // Reset Json Models and UI controls
			 fnReset: function (oEvent) {
                var oTariffTable = this.getView().byId("idTarrifData");
                oTariffTable.setEntitySet("ZPP_CDS_HTS_CLF");
                oTariffTable.rebindTable();
            },
			onBeforeRebindTable: function(oEvent){
                // Access the SmartTable's inner table
                var oTable = oEvent.getSource().getTable();
            
                if (oTable && oTable instanceof sap.ui.table.Table) {
                    // Loop through columns to find the ones you want to replace with links
                    oTable.getColumns().forEach(function (oColumn) {
                        if (oColumn.getAggregation("customData")[0]["mProperties"].value.columnKey === "Material") {
                            // Replace Material column template with a Link
                            oColumn.setTemplate(new sap.m.Link({
                                text: "{Material}",
                                press: this.onMaterialLinkPress.bind(this)                                
                            }));
                        }            
                        if (oColumn.getAggregation("customData")[0]["mProperties"].value.columnKey==="BomID") {
                            // Replace BomID column template with a Link
                            oColumn.setTemplate(new sap.m.Link({
                                text: "{BomID}",
                                press: this.onBomIDLinkPress.bind(this)
                                
                            }));
                        }
                    }.bind(this));
                }
                var binding = oEvent.getParameter("bindingParams");
                var aFilter = this.getOwnerComponent().getModel("local").getProperty("/filterData");
                if(aFilter)
                aFilter.forEach(function(el){
                    binding.filters.push(el);
                });                
            },
            //on click on Material link
            onMaterialLinkPress: function (oEvent) {
                var sMaterial = oEvent.getSource().getText(); 
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "Material",
                        action: "display"
                    },
                    params: {
                        "Material": sMaterial,                       
                    }
                })) || ""; // generate the Hash
                var url = window.location.href.split('#')[0] + hash;
                sap.m.URLHelper.redirect(url, true);               
            },
             //on click on BOM ID link
            onBomIDLinkPress: function (oEvent) {
               //getting material
                var sMaterial =oEvent.getSource().getBindingContext().getObject().Material;
                 //getting BOM Usage
                var sBomUsage =oEvent.getSource().getBindingContext().getObject().BOM_Usage;
                 //getting Plant
                var sPlant =oEvent.getSource().getBindingContext().getObject().Plant;
                 //getting Alternative BOM
                var sAlternativeBOM =oEvent.getSource().getBindingContext().getObject().Alternative_BOM;
                
                
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {                        
                        semanticObject: "BillOfMaterial",
                        action: "display"
                    },
                    params: {
                        
                         "Material": sMaterial,
                         "BomUsage":sBomUsage,
                         "AlternativeBOM":sAlternativeBOM,
                         "Plant":sPlant
                        
                    }
                })) || "";// generate the Hash
                var url = window.location.href.split('#')[0] + hash;
                sap.m.URLHelper.redirect(url, true);
            },

            onBeforeExport: function(oEvent){                
                var aColumns = oEvent.getParameter("exportSettings").workbook.columns
                 var addColumn = ['Material', 'Plant', 'MaterialDescription', 'BomID', 'Alternative_BOM', 'CurrentHTS', 'CalculatedHTS', 'PrimaryPolymer', 'TotalPrimaryPolymerweight', 'TotalPolymerweight', 'TotalPrimarypolymerper'];
                 addColumn.forEach(sCol=>{
                    var iCount=aColumns.filter(col=>col.property === sCol);
                    if(iCount.length === 0){
                        aColumns.push(
                            {
                                label: sCol,
                                property: sCol,
                                type: "String",
                              }
                        );
                    }
                 });

                 oEvent.getParameter("exportSettings").workbook.columns = aColumns;           
            },
			//set smart table settings
			_setSmartTableSettings: function(){
				var oSmartTable = this.byId("idTarrifData");     
				var oTable = oSmartTable.getTable();				
				oTable.setSelectionMode(sap.ui.table.SelectionMode.None);//set selection mode to none
				oTable.setEnableColumnReordering(false);// disable column reordering
				oTable.setEnableColumnFreeze(true); //enable column freeze


 
			}
		});
	});