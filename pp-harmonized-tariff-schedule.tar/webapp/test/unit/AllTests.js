sap.ui.define([
	"comwlpp/zharmonizedtariff/test/unit/controller/Selection.controller"
], function () {
	"use strict";
});
